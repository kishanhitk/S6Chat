package com.example.S6Chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
